app.directive('downloadItem', function () {
    return {
        restrict: 'E',
        templateUrl: 'parts/downloadItem/downloadItem.html'
    }
});